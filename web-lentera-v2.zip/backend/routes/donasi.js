// routes/donasi.js — POST /api/donasi
'use strict';
const express = require('express');
const router = express.Router();
const db = require('../db');

// Sanitize: strip non-printable chars
function sanitize(str) {
    return String(str || '').replace(/[\x00-\x1f\x7f]/g, '').trim().slice(0, 200);
}

// POST /api/donasi
router.post('/', async (req, res) => {
    try {
        const { nama, wa, kecamatan, jumlah, qty_mushaf, atas_nama } = req.body;

        // Validate
        if (!nama || typeof nama !== 'string' || nama.trim().length < 2) {
            return res.status(400).json({ success: false, message: 'Nama tidak valid' });
        }
        if (!wa || typeof wa !== 'string' || wa.trim().length < 7) {
            return res.status(400).json({ success: false, message: 'No. WhatsApp tidak valid' });
        }
        const jumlahInt = parseInt(jumlah);
        if (!jumlahInt || jumlahInt < 1000 || jumlahInt > 1_000_000_000) {
            return res.status(400).json({ success: false, message: 'Jumlah donasi tidak valid' });
        }

        const [result] = await db.execute(
            `INSERT INTO donatur (nama, wa, kecamatan, jumlah, qty_mushaf, atas_nama)
       VALUES (?, ?, ?, ?, ?, ?)`,
            [
                sanitize(nama),
                sanitize(wa),
                kecamatan ? sanitize(kecamatan) : null,
                jumlahInt,
                parseInt(qty_mushaf) || null,
                atas_nama ? sanitize(atas_nama) : null
            ]
        );

        return res.json({ success: true, id: result.insertId });

    } catch (err) {
        console.error('[donasi] DB error:', err.message);
        return res.status(500).json({ success: false, message: 'Kesalahan server, coba lagi' });
    }
});

module.exports = router;
