// server.js — Main Express server
'use strict';
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const donasi = require('./routes/donasi');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ──────────────────────────────────────────────────
app.use(express.json({ limit: '20kb' }));

// CORS: allow same origin (nginx in prod) + localhost for dev
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS
        ? process.env.ALLOWED_ORIGINS.split(',')
        : ['http://localhost', 'http://127.0.0.1', 'null'],  // 'null' for file:// dev
    methods: ['POST', 'GET', 'OPTIONS'],
}));

// Rate limit: max 10 donasi submissions per IP per 15 min
app.use('/api/donasi', rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: { success: false, message: 'Terlalu banyak permintaan. Coba lagi nanti.' }
}));

// ── Routes ──────────────────────────────────────────────────────
app.use('/api/donasi', donasi);

app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', ts: new Date().toISOString() });
});

// ── 404 ─────────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ success: false, message: 'Not found' }));

// ── Start ────────────────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`[LDI Backend] Running on port ${PORT}`);
});
