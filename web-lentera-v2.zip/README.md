# Wakaf Al-Qur'an — Lentera Dakwah Indonesia

Landing page donasi wakaf Al-Qur'an Ramadhan dengan backend Node.js, MySQL, dan deployment Docker.

## Struktur Folder

```
LP Donasi Lentera Dakwah Indoensia/
├── index.html          # Halaman utama
├── style.css           # Semua styling (termasuk success card)
├── script.js           # Logika form, gallery, submit API
├── docker-compose.yml  # Orkestasi 3 container
├── aset foto/          # Gambar & logo
├── backend/
│   ├── server.js       # Express app
│   ├── db.js           # MySQL pool
│   ├── routes/
│   │   └── donasi.js   # POST /api/donasi
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example    # Template env vars
├── database/
│   └── init.sql        # Skema MySQL (auto-run saat container pertama jalan)
└── nginx/
    └── nginx.conf      # Static + API proxy
```

---

## Cara Deploy — EasyPanel

### Persyaratan
- Server VPS (Ubuntu 20.04 / 22.04 disarankan)
- EasyPanel terinstall (`curl -sSL https://easypanel.io/install.sh | sh`)
- Domain atau subdomain sudah diarahkan ke IP server

### Langkah-langkah

**1. Upload file ke server**
```bash
# Dari komputer lokal — zip & upload
zip -r ldi-wakaf.zip . -x "*.DS_Store" "node_modules/*" ".git/*"
scp ldi-wakaf.zip user@IP_SERVER:/home/user/
ssh user@IP_SERVER "cd /home/user && unzip ldi-wakaf.zip -d ldi-wakaf"
```

**2. Buat project di EasyPanel**
- Buka `http://IP_SERVER:3000` → login EasyPanel
- Klik **Create Project** → nama: `ldi-wakaf`

**3. Tambahkan service MySQL**
- Di project → **Add Service** → pilih **MySQL**
- Nama service: `mysql`
- Database: `ldi_wakaf`, User: `ldi`, Password: *(isi password kuat)*
- Klik **Create**

**4. Tambahkan service Backend (Node.js)**
- **Add Service** → **App**
- Source: **Upload Files** atau **Docker Image**
- Jika Docker Image: build dulu manual
  ```bash
  cd /home/user/ldi-wakaf/backend
  docker build -t ldi-backend .
  ```
- Environment variables:
  ```
  DB_HOST=mysql        ← nama service MySQL di EasyPanel
  DB_PORT=3306
  DB_NAME=ldi_wakaf
  DB_USER=ldi
  DB_PASS=PASSWORD_ANDA
  PORT=3000
  WA_ADMIN=6285163698187
  ```
- Port: `3000`

**5. Tambahkan service Nginx (Static Files)**
- **Add Service** → **App** → pakai image `nginx:1.25-alpine`
- Mount folder static ke `/usr/share/nginx/html`
- Mount `nginx/nginx.conf` ke `/etc/nginx/conf.d/default.conf`
- Port: `80`
- Set domain di EasyPanel → tambahkan domain Anda

**6. Inisialisasi Database**
```bash
# Masuk ke container MySQL di EasyPanel terminal atau SSH:
docker exec -it ldi_mysql mysql -u ldi -pPASSWORD ldi_wakaf < /home/user/ldi-wakaf/database/init.sql
```

---

## Cara Deploy — Docker (Server Manual)

```bash
# 1. Copy file ke server
git clone / scp folder ke server

# 2. Buat .env dari template
cp backend/.env.example backend/.env
nano backend/.env   # ← ganti semua password

# 3. Jalankan
docker-compose up -d --build

# 4. Cek status
docker-compose ps

# Buka http://IP_SERVER
```

---

## Development (Lokal tanpa Docker)

```bash
# 1. Jalankan MySQL lokal, import skema
mysql -u root -p < database/init.sql

# 2. Setup backend
cd backend
cp .env.example .env
# Edit .env: DB_HOST=127.0.0.1, dll
npm install
npm run dev   # node --watch server.js

# 3. Buka index.html di browser (file://)
# script.js otomatis detect file:// → pakai localhost:3000
```

---

## Akses Database via DBeaver

DBeaver adalah GUI database yang bagus untuk mengelola data donatur.

### Konfigurasi Koneksi

1. Buka **DBeaver** → **New Database Connection**
2. Pilih **MySQL** → **Next**
3. Isi detail koneksi:

| Field | Nilai |
|---|---|
| **Server Host** | IP server Anda (atau `localhost` jika lokal) |
| **Port** | `3306` |
| **Database** | `ldi_wakaf` |
| **Username** | `ldi` |
| **Password** | *(password di .env Anda)* |

4. Klik **Test Connection** → jika OK → **Finish**

### Jika MySQL di Docker (port tidak terbuka)

Buka port MySQL dulu, edit `docker-compose.yml`:
```yaml
mysql:
  ports:
    - "3306:3306"   # Tambahkan baris ini
```
Lalu `docker-compose up -d`. Setelah koneksi DBeaver OK dan selesai dipakai, bisa dihapus lagi untuk keamanan.

### Query Berguna di DBeaver

```sql
-- Lihat semua donatur terbaru
SELECT id, nama, wa, jumlah, qty_mushaf, atas_nama, created_at
FROM donatur
ORDER BY created_at DESC;

-- Total donasi terkumpul
SELECT
  COUNT(*) AS total_donatur,
  SUM(jumlah) AS total_rupiah,
  SUM(qty_mushaf) AS total_mushaf
FROM donatur;

-- Donasi hari ini
SELECT * FROM donatur
WHERE DATE(created_at) = CURDATE();

-- Export CSV (jalankan di terminal server)
SELECT * FROM donatur INTO OUTFILE '/tmp/donatur_export.csv'
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n';
```

---

## API Endpoint

### `POST /api/donasi`
```json
// Request
{
  "nama": "Abdullah Rahman",
  "wa": "081234567890",
  "jumlah": 400000,
  "qty_mushaf": 5,
  "atas_nama": null
}

// Response OK
{ "success": true, "id": 1 }

// Response Error
{ "success": false, "message": "Nama tidak valid" }
```

### `GET /api/health`
```json
{ "status": "ok", "ts": "2026-02-25T..." }
```

---

## Environment Variables

| Variable | Default | Keterangan |
|---|---|---|
| `DB_HOST` | `mysql` | Hostname MySQL (nama service Docker/EasyPanel) |
| `DB_PORT` | `3306` | Port MySQL |
| `DB_NAME` | `ldi_wakaf` | Nama database |
| `DB_USER` | `ldi` | Username MySQL |
| `DB_PASS` | `rahasia123` | Password MySQL |
| `PORT` | `3000` | Port backend Node |
| `WA_ADMIN` | `6285163698187` | Nomor WhatsApp admin |

> ⚠️ **Wajib ganti password default** sebelum deploy ke production!

---

## Docker Commands

```bash
docker-compose logs -f backend     # Log backend realtime
docker-compose logs -f mysql       # Log MySQL
docker-compose ps                  # Status semua container
docker-compose restart backend     # Restart backend
docker-compose down                # Stop semua
docker-compose down -v             # Stop + HAPUS volume (DATA TERHAPUS!)
```
