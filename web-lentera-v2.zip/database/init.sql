-- ============================================================
-- Lentera Dakwah Indonesia — Wakaf Al-Qur'an Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS ldi_wakaf
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE ldi_wakaf;

CREATE TABLE IF NOT EXISTS donatur (
  id          INT UNSIGNED   AUTO_INCREMENT  PRIMARY KEY,
  nama        VARCHAR(150)   NOT NULL,
  wa          VARCHAR(20)    NOT NULL,
  kecamatan   VARCHAR(150)                   COMMENT 'Kecamatan / Kota domisili donatur',
  jumlah      INT UNSIGNED   NOT NULL          COMMENT 'Jumlah donasi dalam Rupiah',
  qty_mushaf  TINYINT UNSIGNED                 COMMENT 'Estimasi jumlah mushaf',
  atas_nama   VARCHAR(150)                     COMMENT 'Wakaf atas nama (opsional)',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_wa (wa),
  INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
